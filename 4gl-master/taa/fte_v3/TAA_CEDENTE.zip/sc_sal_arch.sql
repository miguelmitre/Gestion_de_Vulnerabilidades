
ALTER    table  taa_cd_saldos_arch
ADD      estado           SMALLINT;

